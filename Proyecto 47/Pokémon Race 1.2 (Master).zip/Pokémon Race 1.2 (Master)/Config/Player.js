class Player {
    constructor() {
        this.name = null;
        this.distance = 0;
        this.index = null;
        this.image = null;
        this.rank = null;
    }
    getCount() {
        database.ref("playerCount").on("value", (data)=> {
            playerCount = data.val();
        });
    }
    updateCount(count) {
        database.ref("/").update({
            playerCount: count
        });
    }
    static getPlayerInfo() {
        database.ref("Players").on("value", (data)=> {
            allPlayers = data.val();
        })
    }
    update() {
        var playerIndex = "Players/Player " + this.index;
        database.ref(playerIndex).set({
            name: this.name,
            distance: this.distance,
            pokemon: this.image,
            rank: this.rank
        });
    }
}
class Login {
    constructor() {
        this.button = createButton("Play");
        this.input = createInput("Name");
        this.greeting = createElement("h3");
        this.title = createElement("h1");
        this.reset = createButton("Reset");
    }
    hide() {
        this.button.hide();
        this.input.hide();
        this.greeting.hide();
        this.title.hide();
    }
    display() {
        this.button.position(canvas.width * (3/5), canvas.height * (2/3));
        this.button.id("button");
        this.input.position(canvas.width * (2/5) - 20, canvas.height * (2/3));
        this.input.id("input");
        if (this.reset !== null) {
        this.reset.position(canvas.width - 100, 100);
        this.reset.id("reset");
        }
        this.greeting.position(canvas.width * (1/5), canvas.height * (1/5));
        this.greeting.id("greeting");
        this.title.position(canvas.width / 2 - canvas.width / 8.5, 20);
        this.title.id("title");
        this.title.html("Pokemon Race");
        this.button.mousePressed(()=> {
            this.input.hide();
            this.button.hide();
            player.name = this.input.value();
            var rand = Math.round(random(1, POKEMONS.length));
            player.image = "images/pokemons/" + POKEMONS[rand - 1] + ".png";
            console.log(player.image);
            playerCount++;
            player.updateCount(playerCount);
            player.index = playerCount;
            player.update();
            this.greeting.html("Welcome " + player.name + " you are player " + player.index);
        });
        if (this.reset !== null) {
            this.reset.mousePressed(()=> {
                player.updateCount(0);
                game.update(0);
                database.ref("/").update({
                    PokemonsAtEnd: 0
                });
                database.ref("Players").remove();
            })
        }
    }
}